// collector.js
// Защищён от повторного внедрения: весь код обёрнут в проверку флага
// на window. При повторной инъекции просто переиспользуется уже
// зарегистрированный обработчик, без повторного объявления переменных
// (иначе "Identifier 'SERVICE' has already been declared").

if (!window.__vyborCollectorLoaded) {
  window.__vyborCollectorLoaded = true;

  const SERVICE = new Set([
    "explore", "reels", "stories", "direct", "accounts", "p", "about",
    "legal", "privacy", "terms", "developer", "directory"
  ]);

  const accumulator = new Map();

  function findLoadMoreButton() {
    const labelRe = /(загрузить|посмотреть|ещё|еще|больше|more comments|load more|view more|view all)/i;
    const svgs = document.querySelectorAll('svg[aria-label]');
    for (const svg of svgs) {
      const label = svg.getAttribute("aria-label") || "";
      if (labelRe.test(label)) {
        const btn = svg.closest('button, [role="button"], div[role="button"]') || svg.parentElement;
        if (btn) return btn;
      }
    }
    const clickables = document.querySelectorAll('button, [role="button"], span');
    for (const el of clickables) {
      const t = (el.textContent || "").trim();
      if (t.length < 40 && labelRe.test(t)) {
        return el.closest('button, [role="button"], div[role="button"]') || el;
      }
    }
    return null;
  }

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  function findScrollContainer() {
    // Instagram часто крутит комментарии во ВНУТРЕННЕМ блоке, а не в окне.
    // Ищем самый большой прокручиваемый контейнер.
    let best = null, bestH = 0;
    document.querySelectorAll('*').forEach(el => {
      const s = getComputedStyle(el);
      if ((s.overflowY === 'auto' || s.overflowY === 'scroll') &&
          el.scrollHeight > el.clientHeight + 50) {
        if (el.scrollHeight > bestH) { bestH = el.scrollHeight; best = el; }
      }
    });
    return best;
  }

  function snapshot() {
    const links = document.querySelectorAll('a[href^="/"]');
    links.forEach(link => {
      const href = link.getAttribute("href") || "";
      const m = href.match(/^\/([A-Za-z0-9._]+)\/$/);
      if (!m) return;
      const username = m[1];
      if (SERVICE.has(username.toLowerCase())) return;
      const linkText = (link.textContent || "").trim();
      if (!linkText || linkText !== username) return;

      let container = link;
      for (let i = 0; i < 4 && container.parentElement; i++) {
        container = container.parentElement;
      }
      let commentText = (container.textContent || "").trim();
      if (commentText.startsWith(username)) {
        commentText = commentText.slice(username.length).trim();
      }
      commentText = commentText
        .replace(/(Нравится|Ответить|Reply|Like)\b.*$/i, "")
        .replace(/\d+\s*(нед|дн|ч|мин|w|d|h|m)\b.*$/i, "")
        .trim();

      // --- отсев мусорных строк ---
      const junkRe = /(Нравится|и ещё \d+|Добавьте ваше мнение|Репост|разрешить сторонние файлы|cookie|Отредактировано|Смотреть все ответы|Отметки)/i;
      if (junkRe.test(commentText)) commentText = "";

      // никнейм уже даёт участника; храним только username как ключ,
      // чтобы один человек не двоился из-за разного текста
      const key = username.toLowerCase();
      if (!accumulator.has(key)) {
        accumulator.set(key, { user: username, text: commentText });
      }
    });
  }

  async function loadAndCollect(onProgress) {
    accumulator.clear();
    const scroller = findScrollContainer();
    let rounds = 0;
    const MAX_ROUNDS = 300;
    let stagnant = 0;
    let lastSize = 0;

    snapshot();

    while (rounds < MAX_ROUNDS) {
      const btn = findLoadMoreButton();
      if (btn) {
        try { btn.scrollIntoView({ block: "center" }); btn.click(); } catch (e) {}
        await sleep(900);
      } else {
        // кнопки нет — крутим контейнер (или окно) вниз, чтобы подгрузить
        if (scroller) {
          scroller.scrollTop = scroller.scrollHeight;
        } else {
          window.scrollTo(0, document.body.scrollHeight);
        }
        await sleep(800);
      }

      snapshot();
      if (onProgress) onProgress(rounds + 1, accumulator.size);

      if (accumulator.size <= lastSize) {
        stagnant++;
        if (stagnant >= 5) break;
      } else {
        stagnant = 0;
      }
      lastSize = accumulator.size;
      rounds++;
    }

    snapshot();
    return Array.from(accumulator.values());
  }

  // регистрируем обработчик ОДИН раз
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === "collect") {
      (async () => {
        try {
          const comments = await loadAndCollect((round, size) => {
            chrome.runtime.sendMessage({ action: "progress", round, size });
          });
          sendResponse({ ok: true, comments });
        } catch (e) {
          sendResponse({ ok: false, error: String(e) });
        }
      })();
      return true;
    }
    return true;
  });
}
