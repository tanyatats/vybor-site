// popup.js — логика всплывающего окна расширения

const VYBOR_URL = "https://tanyatats.github.io/vybor-site/";

const statusEl = document.getElementById("status");
const collectBtn = document.getElementById("collectBtn");
const copyBtn = document.getElementById("copyBtn");
const openBtn = document.getElementById("openVyborBtn");
const output = document.getElementById("output");

let collected = [];

function setStatus(text) {
  statusEl.innerHTML = text;
}

// Слушаем прогресс подгрузки от collector.js
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.action === "progress") {
    setStatus(`Подгружаю... шаг ${msg.round}, собрано: <span class="count">${msg.size || 0}</span>`);
  }
});

collectBtn.addEventListener("click", async () => {
  collectBtn.disabled = true;
  setStatus("Раскрываю все комментарии, это может занять до минуты...");

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  if (!tab.url || !tab.url.includes("instagram.com")) {
    setStatus("Открой пост на instagram.com в этой вкладке.");
    collectBtn.disabled = false;
    return;
  }

  // Внедряем content script и запрашиваем сбор
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["collector.js"]
    });

    chrome.tabs.sendMessage(tab.id, { action: "collect" }, (resp) => {
      collectBtn.disabled = false;

      if (chrome.runtime.lastError) {
        setStatus("Не удалось прочитать страницу. Обнови пост и попробуй снова.");
        return;
      }
      if (!resp || !resp.ok) {
        setStatus("Ошибка при сборе: " + (resp && resp.error ? resp.error : "неизвестно"));
        return;
      }

      collected = resp.comments || [];

      // исключаем ник автора, если указан
      const exclude = (document.getElementById("excludeUser").value || "").trim().toLowerCase().replace(/^@/, "");
      if (exclude) {
        collected = collected.filter(c => c.user.toLowerCase() !== exclude);
      }

      if (collected.length === 0) {
        setStatus("Комментарии не найдены. Прокрути их на странице и попробуй ещё раз.");
        return;
      }

      setStatus(`Собрано участников: <span class="count">${collected.length}</span>`);
      // Формат, который понимает парсер Vybor: "юзернейм: текст"
      const text = collected.map(c => `${c.user}: ${c.text}`).join("\n");
      output.value = text;
      output.style.display = "block";
      copyBtn.style.display = "block";
      openBtn.style.display = "block";
    });
  } catch (e) {
    collectBtn.disabled = false;
    setStatus("Ошибка: " + String(e));
  }
});

copyBtn.addEventListener("click", async () => {
  try {
    await navigator.clipboard.writeText(output.value);
    setStatus("Список скопирован — вставь его в Vybor (простой формат).");
  } catch (e) {
    // запасной вариант
    output.select();
    document.execCommand("copy");
    setStatus("Список скопирован — вставь его в Vybor (простой формат).");
  }
});

openBtn.addEventListener("click", () => {
  chrome.tabs.create({ url: VYBOR_URL });
});
